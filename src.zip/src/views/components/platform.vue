<template>
  <div>
    sssss
  </div>
</template>

<script>
export default {
  data () {
    return {
      modal: false
    }
  },
  methods: {
    ok () {
      this.$Message.info('Clicked ok');
    },
    cancel () {
      this.$Message.info('Clicked cancel');
    }
  }
}
</script>

<style lang="less" scoped>

</style>
