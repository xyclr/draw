<template>
  <div class="container_warp">
    <div class="operating">
      <div class="btn-group">
        <Tooltip content="直线箭头" placement="bottom">
          <div :class=" ['btn',currentArrow === 1?'currentArrow':'']" @click="changeEdgeType('normal')">
            <i class="iconfont icon-ai28"></i>
          </div>
        </Tooltip>
        <Tooltip content="曲线箭头" placement="bottom">
          <div :class=" ['btn',currentArrow === 2?'currentArrow':'']" @click="changeEdgeType('smooth')">
            <i class="iconfont icon-Down-Right"></i>
          </div>
        </Tooltip>
        <Tooltip content="直角箭头" placement="bottom">
          <div :class=" ['btn',currentArrow === 3?'currentArrow':'']" @click="changeEdgeType()">
            <i class="iconfont icon-jiantou"></i>
          </div>
        </Tooltip>
      </div>
      <!-- <div class="btn-group">
        <div class="btn" @click="changeMode('edit')" title="选择模式">
          <i class="iconfont icon-mousepointershubiao"></i>
        </div>
        <div class="btn" @click="changeMode('drag')" title="拖拽模式">
          <i class="iconfont icon-tuozhuai"></i>
        </div>
      </div> -->
      <div class="btn-group">
        <Tooltip content="删除" placement="bottom">
          <div class="btn" @click="deleteNode()" style="margin-top: 5px;">
            <i class="iconfont icon-shanchu"></i>
          </div>
        </Tooltip>
        <Tooltip content="保存PNG" placement="bottom">
          <div class="btn" @click="saveToPNG()" title="保存">
            <i class="iconfont icon-baocun"></i>
          </div>
        </Tooltip>
      </div>
    </div>
    <div class="sidebar">
      <div class="group" :class="{'active': item.name === activeTab}" v-for="item in tabs">
        <div class="mt" @click="activeTab = item.name">
         <span class="title">{{ item.label }}
         </span>

          <span><Icon :type="item.name === activeTab ? 'ios-arrow-down' : 'ios-arrow-forward'"/></span>
        </div>
        <div class="mc">
          <div v-for="sub in item.items" class="btn" :title="sub.label" @mousedown="startDrag(sub.shape,$event)">


            <img :width="sub.width" :height="sub.height" v-if="sub.isImg" :src="sub.src" alt="">
            <i style="font-size: 30px;" v-else="sub.isImg" :class="sub.icon"></i>
          </div>
        </div>
      </div>
    </div>
    <div id="containerChart"></div>
    <Modal
      v-model="bizModelVis"
      width="1000"
      :title="bizModelTitle"
      @on-ok="onBizModelConfirm"
      @on-cancel="bizModelVis = false">
      <Platform :info="bizModelData"/>
    </Modal>
    <RightDrawer class="right_drawer" :drawerType="type" :selectCell="selectCell" :graph="graph" :grid="grid"
                 @deleteNode="deleteNode"></RightDrawer>

  </div>

</template>
<script>
import '@antv/x6-vue-shape'
import {Graph, Shape, Addon, FunctionExt, DataUri} from '@antv/x6';
import RightDrawer from './components/RightDrawer';
import insertCss from 'insert-css';
import {startDragToGraph} from './Graph/methods.js'
import Platform from "./components/platform"

const data = {};
export default {
  components: {
    RightDrawer,
    Platform
  },
  data() {
    return {
      bizModelTitle: '',
      bizModelVis: false,
      bizModelData: false,
      tabs: [
        {
          label: '架构组件',
          name: 'platform',
          items: [
            {
              shape: 'platform',
              label: '平台',
              isImg: true,
              src: require('../assets/platform.png'),
              width: 80,
              height: 60
            },
            {
              shape: 'system',
              label: '系统',
              isImg: true,
              src: require('../assets/system.png'),
              width: 70,
              height: 60
            },
            {
              shape: 'moudle',
              label: '模块',
              isImg: true,
              src: require('../assets/moudle.png'),
              width: 70,
              height: 60
            }

          ]
        },
        {
          label: '接口',
          name: 'interface',
          items: [
            {
              shape: 'interfaceOut',
              label: '内部接口',
              src: require('../assets/interfaceIn.png'),
              isImg: true,
              width: 60,
              height: 30
            },
            {
              shape: 'interfaceIn',
              label: '外部接口',
              isImg: true,
              src: require('../assets/interfaceOut.png'),
              width: 60,
              height: 30
            }
          ]
        },
        {
          label: '常用',
          name: 'gen',
          items: [
            {
              shape: 'Circle',
              label: '圆形',
              isImg: false,
              icon: 'iconfont icon-circle'
            },
            {
              shape: 'Rect',
              label: '方形',
              isImg: false,
              icon: 'iconfont icon-square',
            },
            {
              shape: 'polygon',
              label: '菱形',
              isImg: false,
              icon: 'iconfont icon-square rotate',
            },
          ]
        }
      ],
      activeTab: "platform",
      graph: '',
      value1: true,
      type: 'grid',
      selectCell: '',
      connectEdgeType: {  //连线方式
        connector: 'normal',
        router: {
          name: ''
        }
      },
      showTips: false,
      currentArrow: 1,
      grid: { // 网格设置
        size: 20,      // 网格大小 10px
        visible: true, // 渲染网格背景
        type: 'mesh',
        args: {
          color: '#D0D0D0',
          thickness: 1,     // 网格线宽度/网格点大小
          factor: 10,
        },
      }
    }
  },

  methods: {
    onBizModelConfirm(d) {
      console.log('onBizModelConfirm', d)
      this.bizModelVis  = false;
    },
    initX6() {
      var _that = this


      this.graph = new Graph({
        container: document.getElementById('containerChart'),
        width: 1700,
        height: '100%',
        grid: _that.grid,
        resizing: { //调整节点宽高
          enabled: true,
          orthogonal: false,
        },
        selecting: true, //可选
        snapline: true,
        interacting: {
          edgeLabelMovable: true
        },
        connecting: { // 节点连接
          anchor: 'center',
          connectionPoint: 'anchor',
          allowBlank: false,
          snap: true,
          createEdge() {
            return new Shape.Edge({
              attrs: {
                line: {
                  // stroke: 'red',
                  strokeWidth: 1,
                  targetMarker: {
                    name: 'classic',
                    size: 8
                  },
                  strokeDasharray: 0, //虚线
                  style: {
                    animation: 'ant-line 30s infinite linear',
                  },
                },
              },
              label: {
                text: '',  // 设置默认 label 为 "平台"
                fontSize: 32,  // 设置字体大小
                fill: 'green',  // 设置字体颜色
              },
              connector: _that.connectEdgeType.connector,
              router: {
                name: _that.connectEdgeType.router.name || ''
              },
              zIndex: 0
            })
          },
        },
        embedding: {
          enabled: true,
          findParent({ node }) {
            console.log('findParent', node)
            const bbox = node.getBBox()
            return this.getNodes().filter((node) => {
              // 只有 data.parent 为 true 的节点才是父节点
              const data = node.getData()
              console.log('findParent getData', data)
              if (data && data.parent) {
                const targetBBox = node.getBBox()
                return bbox.isIntersectWithRect(targetBBox)
              }
              return false
            })
          }
        },
        highlighting: {
          magnetAvailable: {
            name: 'stroke',
            args: {
              padding: 4,
              attrs: {
                strokeWidth: 4,
                stroke: '#6a6c8a'
              }
            }
          }
        },
      });
      insertCss(`
              @keyframes ant-line {
                to {
                    stroke-dashoffset: -1000
                }
              }
            `)
      this.graph.fromJSON(data)
      this.graph.history.redo()
      this.graph.history.undo()
      // 鼠标移入移出节点
      this.graph.on('node:mouseenter', FunctionExt.debounce(() => {
          const container = document.getElementById('containerChart')
          const ports = container.querySelectorAll(
            '.x6-port-body'
          )
          this.showPorts(ports, true)
        }),
        500
      )
      this.graph.on('node:mouseleave', () => {
        const container = document.getElementById('containerChart')
        const ports = container.querySelectorAll(
          '.x6-port-body'
        )
        this.showPorts(ports, false)
      })
      this.graph.on('blank:click', () => {
        this.type = 'grid'
      })
      this.graph.on('cell:click', ({cell}) => {
        this.type = cell.isNode() ? 'node' : 'edge'
      })


      this.graph.on('cell:dblclick', ({node, cell}) => {
        this.bizModelVis = true;
        node.setData({
          bizData: '1111'
        })
        this.bizModelTitle = '应用属性'
        this.bizModelData = {
          xxx: '1111'
        }
        console.log('xxxxx', node, cell, node.getData())
      })
      this.graph.on('selection:changed', (args) => {
        args.added.forEach(cell => {
          this.selectCell = cell
          if (cell.isEdge()) {
            cell.isEdge() && cell.attr('line/strokeDasharray', 5) //虚线蚂蚁线
            cell.addTools([
              {
                name: 'vertices',
                args: {
                  padding: 4,
                  attrs: {
                    strokeWidth: 0.1,
                    stroke: '#2d8cf0',
                    fill: '#ffffff',
                  }
                },
              },
            ])
          }
        })
        args.removed.forEach(cell => {
          cell.isEdge() && cell.attr('line/strokeDasharray', 0)  //正常线
          cell.removeTools()
        })
      })
    },
    showPorts(ports, show) {
      for (let i = 0, len = ports.length; i < len; i = i + 1) {
        ports[i].style.visibility = show ? 'visible' : 'hidden'
      }
    },
    // 拖拽生成正方形或者圆形
    startDrag(type, e) {
      startDragToGraph(this.graph, type, e)
    },
    // 删除节点
    deleteNode() {
      const cell = this.graph.getSelectedCells()
      this.graph.removeCells(cell)
      this.type = 'grid'
    },
    // 保存png
    saveToPNG() {
      this.$nextTick(() => {
        this.graph.toPNG((dataUri) => {
          // 下载
          DataUri.downloadDataUri(dataUri, '资产拓扑图.png')
        }, {
          backgroundColor: 'white',
          padding: {
            top: 50,
            right: 50,
            bottom: 50,
            left: 50
          },
          quality: 1,
          copyStyles: false
        })
      })

    },
    // 改变边形状
    changeEdgeType(e) {
      if (e === 'normal') {
        this.connectEdgeType = {
          connector: 'normal',
          router: {name: ''}
        }
        this.currentArrow = 1
      } else if (e === 'smooth') {
        this.connectEdgeType = {
          connector: 'smooth',
          router: {name: ''}
        }
        this.currentArrow = 2
      } else {
        this.connectEdgeType = {
          connector: 'normal',
          router: {name: 'manhattan'}
        }
        this.currentArrow = 3
      }
    }
  },
  mounted() {
    this.initX6()
    setTimeout(() => {
      this.showTips = true
    }, 1000)
    setTimeout(() => {
      this.showTips = false
    }, 5000)
  }
};
</script>
<style lang="less">
@import '../assets/iconfont.css';
@import './index.less';

.container_warp {
  display: flex;
  height: 100vh;
}

.sidebar {
  box-shadow: 2px 2px 4px 0 #0a0a0a2e;
  width: 220px;
  background-color: #f7f7f7;
  display: flex;
  flex-direction: column;
  justify-content: space-around;
  position: fixed;
  left: 0px;
  top: 50%;
  margin-top: -100px;
  background: #fff;
  border-top: 5px solid #ddd;
  border-bottom: none;
  z-index: 999;
  padding: 0;

  .rotate {
    display: inline-block;
    transform: rotate(45deg);
  }

  .group {
    border-bottom: 1px solid #ddd;
    width: 100%;

    &.active {
      .mc {
        display: block;
      }
    }

    .mt {
      display: flex;
      height: 30px;
      line-height: 30px;
      justify-content: space-between;
      padding: 0 10px;
      cursor: pointer;
    }

    .mc {
      display: none;

      > div {
        display: inline-block;
        padding: 10px;
      }
    }


  }
}
</style>
